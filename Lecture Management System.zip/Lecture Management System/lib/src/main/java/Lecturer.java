
public class Lecturer {
	public
	int id;
	String name;
	int age;
	String DOB;
	String username;
	String[] modulesTeaching;
	
	//Accessors
	public void getId() {
		
	}
	public void getName() {
		
	}
	public void getAge() {
		
	}
	public void getDOB() {
		
	}
	public void getUsername()
	{
		System.out.println(name + " " + age);
	}
	public void getModulesTeaching() {
		
	}
	
	//Mutators
	public void setId(int idS) {
		id = idS;
	}
	public void setName(String nameS) {
		name = nameS;
	}
	public void setAge(int ageS) {
		age = ageS;
	}
	public void setDOB(String dobS) {
		DOB = dobS;
	}
	public void setModulesTeaching(String moduleS) {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
